<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'marcywil_wo1173');

/** MySQL database username */
define('DB_USER', 'marcywil_wo1173');

/** MySQL database password */
define('DB_PASSWORD', 'kiTj8sPUhM2e');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'sP>z|?=Q{WfQgtsIhyWc@wcz?{j_|/-++edgOSIUq@{X<?tzc<Z+UpzFgsPnWU<B{ukVzT$Rq$nnF]=JUPcfIMpP=*bFr@{=VewoMF&[^cfeZaM+UMc&uBWBPMRzc?Ca');
define('SECURE_AUTH_KEY', 'p)x$LM@dPIAQ)*NrAo=j;rCbIIX>r@eZ;AbG(tENPhSIM;ey=ayXRB!Z]b{SGN)qJwP|V}|v|yqy%i*Un+U&Vmtx}dls!kkV!vX{XMeG<qHJpvApqly((pBtxCoKF}Vz');
define('LOGGED_IN_KEY', 'S_uxZc&G+OxMjSDQ_NDacaYlT([INdjU=EB(|FQ{;%WEv>a-olUdQogatD&TKa<?R-D{&DxICLW])+pj>]b/Y($DyW@lVk/IEQPPWP^jUZkz]$S[X-Xd;+|DA/pBIp]&');
define('NONCE_KEY', ';egUo(o@)jJ<dyVWv&r;@BU*QD!!V=kCjq>SM(O%HH)[!sGVUdR};=]ep|GuR%lZ)*ld<FDE;&zcg!gMzP|TLoMZSpbtG;q<mzul=gq)RTBtzkyWEmBi=Mipu*>ulegc');
define('AUTH_SALT', 'a%H<_-y%}^TQ|lWAv+(g!d^muJM!/V]hPEZUJ/nVDv;IzQIQu[u]kHi]]Tv?=e<R>sH*tE)!JJ-Q<wc(j/w+[IGpd}_rTuKe-rQC$R/zI>vyNFOj%pRUWDmE$V{SMa|-');
define('SECURE_AUTH_SALT', '|v(I}=NtYqyn%[{|_l@CCqePIc*({bbMKBUy*wAoa*MPo%pHNgk$FguV?PQwOUDhxyl|!)x;IRWNg(o?}tEuc>CJYYYo^St}}*u*gzRecB_ebALcUU_QmRg[)iIc*@)W');
define('LOGGED_IN_SALT', '%xTu[v&ake]d*U^@lK;cLErVE=CpDb&O*e@<uyOcgAF(!AmyfQjvW=gt/zj?ubIPbVzIj-miJN*are@gUB}wIiK-H$b*v&qm_aT!JRTy=fhbngNI*MO)yX<Wf>/H)<iO');
define('NONCE_SALT', 'MqCxoWTbdKlMfS$v$[@v<JX+&{PhbGm}RbacE&;pSU(pi*N>p|NBP^R]@p$d@A@C$FD/YX[!x}/?T]AVDENvJeTUR@<rjM_kkBd&D((HRP]<dWiKL_^_bROEp-TIIVEe');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_bogz_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

/**
 * Include tweaks requested by hosting providers.  You can safely
 * remove either the file or comment out the lines below to get
 * to a vanilla state.
 */
if (file_exists(ABSPATH . 'hosting_provider_filters.php')) {
	include('hosting_provider_filters.php');
}
